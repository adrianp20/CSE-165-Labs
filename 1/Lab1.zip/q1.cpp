// Hello world program
// Write a program that prints out: Hi, my name is [Your Name]!

#include <iostream>

using namespace std;

int main() {
    cout << "Hi, my name is Adrian!" << endl;
    return 0;

}