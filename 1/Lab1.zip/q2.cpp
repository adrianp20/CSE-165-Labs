// Area of a circle
// Create a program that asks for the radius of a circle and prints the area of that circle.

#include <iostream>

using namespace std;

int main() {
    double radius;
    cout << "Enter the radius of the circle: ";
    cin >> radius;
    cout << "The area of the circle is: " << 3.14159 * radius * radius << endl;
    return 0;
}
